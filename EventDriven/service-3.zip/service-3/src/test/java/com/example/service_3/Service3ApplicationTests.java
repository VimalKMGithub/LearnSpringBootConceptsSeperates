package com.example.service_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Service3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
